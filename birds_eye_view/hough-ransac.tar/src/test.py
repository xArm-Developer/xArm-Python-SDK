import numpy as np 
import cv2

kernel = np.ones((2,2),np.uint8)
# load image
img = cv2.imread(r"C:\Users\David\Downloads\rack.jpg")
img = cv2.resize(img, (300, 300), fx = 0.25, fy = 0.25)

kernel = np.ones((2,2),np.uint8)
# load image
img = cv2.resize(img, (300, 300), fx = 0.25, fy = 0.25)

# Convert BGR to HSV
hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
bw  = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# define range of black color in HSV
lower_val = np.array([0, 150, 60])
upper_val = np.array([179,255,255])

# Threshold the HSV image to get only black colors
mask = cv2.inRange(hsv, lower_val, upper_val)

# Bitwise-AND mask and original image
res = cv2.bitwise_and(img,img, mask= mask)
# invert the mask to get black letters on white background
res2 = cv2.bitwise_not(mask)
res2 = cv2.bitwise_not(res2)

cv2.imshow("img", res)
cv2.imshow("img2", res2)
# cv2.imshow("bw", bw)
cv2.imshow("hsv", hsv)


cv2.waitKey(0)
cv2.destroyAllWindows()