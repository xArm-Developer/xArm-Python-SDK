
	# cv.ADAPTIVE_THRESH_MEAN_C, cv.THRESH_BINARY_INV, 21, 10)
    # kernel = np.ones((5,5),np.uint8)
    # thresh = cv.dilate(thresh,kernel,iterations = 2)
    # # thresh = cv.morphologyEx(thresh, cv.MORPH_OPEN, kernel,iterations = 1)
    # thresh = cv.morphologyEx(thresh, cv.MORPH_CLOSE, kernel,iterations = 1)