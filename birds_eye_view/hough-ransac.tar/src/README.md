# ECLAIR-PCR-ObjectLocator
Program to detect objects and determine their coordinates within an environment.
