# from skimage.exposure import is_low_contrast
import numpy as np
import argparse
import imutils
import cv2

# construct the argument parser and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-i", "--input", type=str, default="",
	help="optional path to video file")
ap.add_argument("-t", "--thresh", type=float, default=0.35,
	help="threshold for low contrast")
args = vars(ap.parse_args())

# grab a pointer to the input video stream
print("[INFO] accessing video stream...")
vs = cv2.VideoCapture(args["input"] if args["input"] else 0)
sensitivity = 15
# loop over frames from the video stream
while True:
	# read a frame from the video stream
	(grabbed, frame) = vs.read()
	# if the frame was not grabbed then we've reached the end of
	# the video stream so exit the script
	if not grabbed:
		print("[INFO] no frame read from stream - exiting")
		break
	kernel = np.ones((2,2),np.uint8)
	# load image
	frame = cv2.resize(frame, (300, 300), fx = 0.25, fy = 0.25)

	# Convert BGR to HSV
	hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
	bw  = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

	# define range of black color in HSV
	lower_val = np.array([0, 150, 60])
	upper_val = np.array([179,255,255])
	
	# Threshold the HSV image to get only black colors
	mask = cv2.inRange(hsv, lower_val, upper_val)

	# Bitwise-AND mask and original image
	res = cv2.bitwise_and(frame,frame, mask= mask)
	# invert the mask to get black letters on white background
	res2 = cv2.bitwise_not(mask)
	res2 = cv2.bitwise_not(res2)


	contours, _ = cv2.findContours(res2,cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE)
	contour = max(contours, key = len)

	x,y,w,h = cv2.boundingRect(contour)

	frame = cv2.drawContours(frame,[contour],0,(0,255,255),2)
	frame = cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,0),2)

	cv2.imshow("img", res)
	cv2.imshow("img2", res2)
	# cv2.imshow("bw", bw)
	cv2.imshow("hsv", hsv)
	cv2.imshow("OG", frame)

	key = cv2.waitKey(1) & 0xFF
	# if the `q` key was pressed, break from the loop
	if key == ord("q"):
		break