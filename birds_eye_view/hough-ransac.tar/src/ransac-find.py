import cv2
import numpy as np

# Initialize the OpenCV video capture object
videoCapture = cv2.VideoCapture(1, cv2.CAP_DSHOW)

# Define the parameters for the HoughCircles function
min_radius = 10
max_radius = 50
dp = 1
min_dist = 50

# Define the parameters for the RANSAC algorithm
threshold = 3
num_iterations = 1000

while True:
    # Capture a frame from the video stream
    ret, frame = videoCapture.read()
    
    # Convert the image to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    # Apply a Gaussian blur filter to the image
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    
    # Detect circles in the image using HoughCircles
    circles = cv2.HoughCircles(blurred, cv2.HOUGH_GRADIENT, dp, min_dist,
                               param1=100, param2=50, minRadius=min_radius,
                               maxRadius=max_radius)
    
    if circles is not None:
        circles = np.round(circles[0, :]).astype("int")
        
        # Run RANSAC algorithm to remove false positives
        best_circle = None
        best_num_inliers = 0
        for i in range(num_iterations):
            # Randomly select three circles
            sample = circles[np.random.choice(len(circles), 3, replace=False)]
            
            # Fit a circle to the selected points
            (x, y), r = cv2.minEnclosingCircle(sample)
            
            # Calculate the number of inliers for the fitted circle
            num_inliers = 0
            for (x0, y0, r0) in circles:
                if np.sqrt((x - x0) ** 2 + (y - y0) ** 2) <= r + threshold:
                    num_inliers += 1
            
            # Update the best circle if the current circle has more inliers
            if num_inliers > best_num_inliers:
                best_num_inliers = num_inliers
                best_circle = (x, y, r)
        
        # Draw the detected circle on the original image
        if best_circle is not None:
            x, y, r = best_circle
            cv2.circle(frame, (int(x), int(y)), int(r), (0, 255, 0), 2)

    # Display the resulting frame
    cv2.imshow("circles", frame)
    # cv.imshow("Thresholded image", thresh)
    # cv.imshow("Masked image", result)
    cv2.imshow("grayscale", gray)
    if cv2.waitKey(1) == ord('q'):
        break
videoCapture.release()
cv2.destroyAllWindows()
